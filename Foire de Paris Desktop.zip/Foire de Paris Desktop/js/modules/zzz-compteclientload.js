/** PREPARE LE CHARGEMENT DU WIDGET **/

$(document).ready(function() {
    $("div#cxpmClientAccountWidget");
});
